﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace EDziennik.Migrations
{
    public partial class Markviews : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
